###### Check, installation and loading of required packages #######
requiredPackages = c("readr") # list of required packages
for(i in requiredPackages){
  if(!require(i,character.only = TRUE)) install.packages(i)
  library(i,character.only = TRUE) } 

dataset_q_and_score <- read_delim("dataset_q_and_score.csv", ";", escape_double = FALSE, trim_ws = TRUE)